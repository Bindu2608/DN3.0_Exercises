package Excersice5;

public interface Notifier {
    void send(String message);
}
