package Excersice5;

public class DecoratorTest {
    public static void main(String[] args) {

        Notifier emailNotifier = new EmailNotifier();


        Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);


        smsEmailNotifier.send("Hello World!");
    }
}
