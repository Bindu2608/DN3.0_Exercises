package Excersice7;

public interface Observer {
    void update(double price);
}
