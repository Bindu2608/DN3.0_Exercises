package Excersice10;

public class MVCTest {
    public static void main(String[] args) {
        // Create a Student model object
        Student student = new Student("Bindu", "12345", "A");

        // Create a StudentView object
        StudentView view = new StudentView();

        // Create a StudentController object
        StudentController controller = new StudentController(student, view);

        controller.updateView();
        controller.setStudentName("Bindu");
        controller.setStudentGrade("B");

        // Display updated student details
        controller.updateView();
    }
}
