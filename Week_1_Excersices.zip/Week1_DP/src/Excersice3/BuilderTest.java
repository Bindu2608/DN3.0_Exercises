package Excersice3;

public class BuilderTest {
    public static void main(String[] args) {

        Computer computer1 = new Computer.Builder("Intel i5", "8GB")
                .setStorage("1TB")
                .build();

        Computer computer2 = new Computer.Builder("AMD Ryzen 5", "16GB")
                .setStorage("500GB SSD")
                .setGraphicsCard("NVIDIA GTX 1660")
                .build();


        System.out.println(computer1);
        System.out.println(computer2);
    }
}
