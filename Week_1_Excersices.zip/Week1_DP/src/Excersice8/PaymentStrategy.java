package Excersice8;

public interface PaymentStrategy {
    void pay(double amount);
}
