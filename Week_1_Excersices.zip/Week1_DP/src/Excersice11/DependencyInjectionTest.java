package Excersice11;

public class DependencyInjectionTest {
    public static void main(String[] args) {

        CustomerRepository customerRepository = new CustmRepoImpl();

        CustmService customerService = new CustmService(customerRepository);

        Custm customer = customerService.getCustomerById(1);

        System.out.println(customer);
    }
}
