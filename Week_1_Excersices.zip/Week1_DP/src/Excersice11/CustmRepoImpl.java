package Excersice11;

public class CustmRepoImpl implements CustomerRepository {
    @Override
    public Custm findCustomerById(int id) {
        // Simulate fetching a customer from a data source
        return new Custm(id, "John Doe");
    }
}
