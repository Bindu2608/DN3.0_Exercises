package Excersice11;

public class CustmService {
    private CustomerRepository customerRepository;

    // Constructor Injection
    public CustmService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Custm getCustomerById(int id) {
        return customerRepository.findCustomerById(id);
    }
}
