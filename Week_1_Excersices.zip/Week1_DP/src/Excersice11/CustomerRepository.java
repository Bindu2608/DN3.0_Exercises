package Excersice11;

public interface CustomerRepository {
    Custm findCustomerById(int id);
}
