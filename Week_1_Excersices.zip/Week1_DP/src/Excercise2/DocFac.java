package Excersice2;

public abstract class DocFac{
    public abstract Doc createDocument();
}

