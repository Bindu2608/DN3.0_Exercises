package Excersice2;

public class PdfDocFac extends DocFac {

    @Override
    public Doc createDocument() {
        return new PdfDoc();
    }
}

