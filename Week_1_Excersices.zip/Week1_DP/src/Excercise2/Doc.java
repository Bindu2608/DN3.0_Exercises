package Excersice2;


	public interface Doc{
	    void open();
	    void close();
	    void save();
	}



	
