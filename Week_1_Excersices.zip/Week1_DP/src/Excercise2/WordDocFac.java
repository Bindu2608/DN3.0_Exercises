package Excersice2;

public class WordDocFac extends DocFac{

    @Override
    public Doc createDocument() {
        return new WordDoc();
    }
}

