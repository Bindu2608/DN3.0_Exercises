package Excersice2;

public class ExcelDocFac extends DocFac {

    @Override
    public Doc createDocument() {
        return new ExcelDoc();
    }
}

