package Excersice2;

public class Main {

    public static void main(String[] args) {
        DocFac wordFactory = new WordDocFac();
        Doc wordDoc = wordFactory.createDocument();
        wordDoc.open();
        wordDoc.save();
        wordDoc.close();

        DocFac pdfFactory = new PdfDocFac();
        Doc pdfDoc = pdfFactory.createDocument();
        pdfDoc.open();
        pdfDoc.save();
        pdfDoc.close();

        DocFac excelFactory = new ExcelDocFac();
        Doc excelDoc = excelFactory.createDocument();
        excelDoc.open();
        excelDoc.save();
        excelDoc.close();
    }
}
