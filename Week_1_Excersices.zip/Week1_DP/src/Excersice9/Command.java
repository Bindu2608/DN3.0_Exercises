package Excersice9;

public interface Command {
    void execute();
}
