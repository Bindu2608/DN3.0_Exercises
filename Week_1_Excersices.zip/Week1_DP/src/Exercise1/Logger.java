package Exersice1;

public class Logger {

    // Private static instance of the same class
    private static Logger instance;

    // Private constructor to restrict instantiation from outside
    private Logger() {
        // Private constructor to prevent instantiation
    }

    // Public method to provide access to the instance
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) { // Double-checked locking
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Example method to demonstrate logging
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
