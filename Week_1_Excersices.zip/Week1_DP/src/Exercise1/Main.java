package Exersice1;

public class Main {
	

	    public static void main(String[] args) {
	        // Get the only instance of Logger
	        Logger logger1 = Logger.getInstance();
	        Logger logger2 = Logger.getInstance();

	        // Test if both logger1 and logger2 are the same instance
	        System.out.println("Are both logger instances the same? " + (logger1 == logger2));

	        // Use the logger to log a message
	        logger1.log("This is a log message.");
	        logger2.log("This is another log message.");
	    }
	}



