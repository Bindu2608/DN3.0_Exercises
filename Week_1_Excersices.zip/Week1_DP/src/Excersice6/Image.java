package Excersice6;

public interface Image {
    void display();
}
