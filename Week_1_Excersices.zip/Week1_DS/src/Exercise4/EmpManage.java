package Exercise4;

public class EmpManage {
	
	    private Emp[] employees;
	    private int size;

	    public EmpManage(int capacity) {
	        Emp[] Emp = new Emp[capacity];
	        size = 0;
	    }

	    public boolean addEmployee(Emp employee) {
	        if (size == employees.length) {
	            System.out.println("Array is full. Cannot add more employees.");
	            return false;
	        }
	        employees[size++] = employee;
	        return true;
	    }

	    public Emp searchEmployee(int employeeId) {
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getEmployeeId() == employeeId) {
	                return employees[i];
	            }
	        }
	        return null;
	    }

	    public boolean deleteEmployee(int employeeId) {
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getEmployeeId() == employeeId) {
	                employees[i] = employees[size - 1]; // Replace with last employee
	                employees[size - 1] = null;
	                size--;
	                return true;
	            }
	        }
	        return false;
	    }

	    public void traverseEmployees() {
	        for (int i = 0; i < size; i++) {
	            System.out.println(employees[i]);
	        }
	    }

	    public static void main(String[] args) {
	        EmpManage ems = new EmpManage(5);
	        ems.addEmployee(new Emp(1, "Alice", "Manager", 70000));
	        ems.addEmployee(new Emp(2, "Bob", "Developer", 50000));
	        ems.addEmployee(new Emp(3, "Charlie", "Analyst", 60000));

	        System.out.println("Traversing employees:");
	        ems.traverseEmployees();

	        System.out.println("\nSearching for employee with ID 2:");
	        Emp e = ems.searchEmployee(2);
	        System.out.println(e != null ? e : "Employee not found.");

	        System.out.println("\nDeleting employee with ID 2:");
	        boolean deleted = ems.deleteEmployee(2);
	        System.out.println(deleted ? "Employee deleted." : "Employee not found.");

	        System.out.println("\nTraversing employees after deletion:");
	        ems.traverseEmployees();
	    }
	}



