package Excercise1;


	import java.util.HashMap;

	public class Inventory {
	    private HashMap<String, Product> inventory;

	    public Inventory() {
	        inventory = new HashMap<>();
	    }

	    // Add a product to the inventory
	    public void addProduct(Product product) {
	        inventory.put(product.getProductId(), product);
	    }

	    // Update a product in the inventory
	    public void updateProduct(Product product) {
	        if (inventory.containsKey(product.getProductId())) {
	            inventory.put(product.getProductId(), product);
	        } else {
	            System.out.println("Product not found in inventory.");
	        }
	    }

	    // Delete a product from the inventory
	    public void deleteProduct(String productId) {
	        if (inventory.containsKey(productId)) {
	            inventory.remove(productId);
	        } else {
	            System.out.println("Product not found in inventory.");
	        }
	    }

	    // Retrieve a product from the inventory
	    public Product getProduct(String productId) {
	        return inventory.get(productId);
	    }
	}



