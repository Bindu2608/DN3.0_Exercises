package Excercise1;

public class Main {

	    public static void main(String[] args) {
	        Inventory inventory = new Inventory();

	        // Adding products
	        Product product1 = new Product("P001", "Laptop", 10, 1000.0);
	        Product product2 = new Product("P002", "Smartphone", 20, 500.0);
	        inventory.addProduct(product1);
	        inventory.addProduct(product2);

	        // Updating a product
	        Product updatedProduct = new Product("P001", "Laptop", 15, 950.0);
	        inventory.updateProduct(updatedProduct);

	        // Deleting a product
	        inventory.deleteProduct("P002");

	        // Retrieving a product
	        Product retrievedProduct = inventory.getProduct("P001");
	        if (retrievedProduct != null) {
	            System.out.println("Product ID: " + retrievedProduct.getProductId());
	            System.out.println("Product Name: " + retrievedProduct.getProductName());
	            System.out.println("Quantity: " + retrievedProduct.getQuantity());
	            System.out.println("Price: " + retrievedProduct.getPrice());
	        }
	    }
	}



