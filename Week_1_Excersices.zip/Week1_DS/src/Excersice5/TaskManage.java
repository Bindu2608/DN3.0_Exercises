package Excersice5;

public class TaskManage {
	
	    private class Node {
	        Task task;
	        Node next;

	        Node(Task task) {
	            this.task = task;
	        }
	    }

	    private Node head;

	    public void addTask(Task task) {
	        Node newNode = new Node(task);
	        newNode.next = head;
	        head = newNode;
	    }

	    public Task searchTask(int taskId) {
	        Node current = head;
	        while (current != null) {
	            if (current.task.getTaskId() == taskId) {
	                return current.task;
	            }
	            current = current.next;
	        }
	        return null;
	    }

	    public boolean deleteTask(int taskId) {
	        if (head == null) return false;

	        if (head.task.getTaskId() == taskId) {
	            head = head.next;
	            return true;
	        }

	        Node current = head;
	        while (current.next != null && current.next.task.getTaskId() != taskId) {
	            current = current.next;
	        }

	        if (current.next != null) {
	            current.next = current.next.next;
	            return true;
	        }
	        return false;
	    }

	    public void traverseTasks() {
	        Node current = head;
	        while (current != null) {
	            System.out.println(current.task);
	            current = current.next;
	        }
	    }

	    public static void main(String[] args) {
	        TaskManage tms = new TaskManage();
	        tms.addTask(new Task(1, "Design", "Incomplete"));
	        tms.addTask(new Task(2, "Implementation", "Incomplete"));
	        tms.addTask(new Task(3, "Testing", "Incomplete"));

	        System.out.println("Traversing tasks:");
	        tms.traverseTasks();

	        System.out.println("\nSearching for task with ID 2:");
	        Task t = tms.searchTask(2);
	        System.out.println(t != null ? t : "Task not found.");

	        System.out.println("\nDeleting task with ID 2:");
	        boolean deleted = tms.deleteTask(2);
	        System.out.println(deleted ? "Task deleted." : "Task not found.");

	        System.out.println("\nTraversing tasks after deletion:");
	        tms.traverseTasks();
	    }
	}



